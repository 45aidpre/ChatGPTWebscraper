# from unitTests.ChatGPTScraper import ChatGpt
#
# chatbot = ChatGpt()
#
# chatbot.open_ChatGpt_Login_N_Plus()
#
# chatbot.accessLogin()
#
# chatbot.access_plus_model()
